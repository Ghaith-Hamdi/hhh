#include <iostream>
#include <algorithm>
#include <vector>

//A lambda expression is an anonymous, inline function.
//It is used to create a local function, mainly for passing as an argument to a function call or as a return value

int main()
{
	std::vector<int> vec{ 1,2,3,4,5,6,7,8 };

	auto lambda = [](int i) -> bool //In C++11, type is deduced only for single line lambdas
	{
			return i % 2 != 0;
	};
	std::count_if(vec.begin(), vec.end(), lambda);

	int num{ 4 };
	auto lambda = [num](int i) -> bool//we captured a value and used it the lambda
		{
			return i % num != 0;
		};


	auto lam = [](int i)
		{
			std::cout << i + 1;
		};
	lam(1);
	//capture a variable : make it available in the lambda's body
	int x{ 4 }, a{ 1 }, b{ 2 };
	auto lam_val = [x]() {};//capture x by value
	auto lam_ref = [&x]() {};//capture x by ref : to be able to modify it

	auto lam_val1 = [=]() {};//capture all by value
	auto lam_ref1 = [&]() {};//capture all by ref

	auto lam_mix1 = [=, &x]() {};//capture x by ref, all others by value
	auto lam_mix2 = [&, a, b]() {};//capture a and b by value, all others by ref

	//auto lam_mem_class = [this]() {};//capture all date members (by ref) 
}