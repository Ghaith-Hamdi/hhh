#include <iostream>
#include <vector>
#include <typeinfo>
#include <chrono>

using namespace std::chrono;
using namespace std::chrono_literals;

void func(int x)
{
	std::cout << "by value" << std::endl;
}
void func(int*x)
{
	std::cout << "by pointer" << std::endl;
}

int main()
{
	//Narrowing Conversions : not allowed
	//int i{ 123.254 };//compiler error
	int j{ 1 }, d{ 2 };//warning
	std::vector<int> vec{ 4,2,3,5,1 };
	
	for (/*std::vector<int>::iterator*/ auto it = vec.begin(); it != vec.end(); it++)
	{
		//std::cout << *it << "\t";
	}

	func(j);//by value
	int* k{ &d };
	func(k);//by pointer

	//nullptr : compatible with any pointer type
	//value(nullptr);//cannot be converted to an integer
	func(nullptr);//by pointer
	
	//NULL value : 0
	//NULL type : implementation defined
	func(NULL);//by value

	//std::chrono
	//C++ 11
	seconds{ 2 };
	milliseconds{ 20 };
	microseconds{ 50 };
	//C++ 14
	2s;
	20ms;
	50us;
	
	auto vv = 6;
	const std::string& str = "hello";//reference to const
	auto hello = str;//hello has type std::string
	//=> const, references, etc are ignored by auto
	//we have to add them ourselves
	//const auto& str = hello;

	std::vector<int> v1 {1, 2, 3, 4, 5};
	std::vector<int> v2 {1, 2, 3, 4, 5 };
	std::vector<int>::iterator it1;
	for (it1 = v1.begin(); it1 != v1.end();it1++)
	{
		*it1 += 2;
	}
	for (it1 = v1.begin(); it1 != v1.end();it1++)
	{
		std::cout << *it1;
	}
	std::cout << "\n";
	for (auto &it2 : v2)//add & to modify the values
	{
		it2 += 2;
	}
	for (auto it3 : v2)
	{
		std::cout << it3;
	}
}